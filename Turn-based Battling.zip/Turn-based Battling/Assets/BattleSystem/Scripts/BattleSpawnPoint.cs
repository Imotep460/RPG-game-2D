﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace BattleSystem
{
    public class BattleSpawnPoint : MonoBehaviour
    {
        public BattleCharacter Spawn(BattleCharacter battleCharacter)
        {
            BattleCharacter characterToSpawn = Instantiate<BattleCharacter>(battleCharacter, this.transform);
            return characterToSpawn;
        }
    }
}